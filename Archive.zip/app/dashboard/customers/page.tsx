export default function Page(){
    return <>
    <p>Customer Page</p>
    </>
}